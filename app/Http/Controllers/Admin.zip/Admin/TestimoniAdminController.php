<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Testimoni;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Carbon;


class TestimoniAdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datas = DB::table('testimoni')
                    ->select('testimoni.*')
                    // ->orderBy('id', 'desc')
                    ->get();
        return view('admin.testimoni.index', compact('datas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.testimoni.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //validasi data
        $validasiData = $request->validate([
            'fembed_youtube' => 'required',
            'kutipan' => 'required'
        ]);

        //create ke database
        Testimoni::create([
			'fembed_youtube' => $request->fembed_youtube,
			'kutipan' => $request->kutipan,
		]);
    
        return redirect('testimoni_admin')->with('massage', 'Berhasil Menambah Testimoni');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      
        $datas = Testimoni::findOrFail($id);  
        return view('admin.testimoni.edit', compact('datas'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validasiData = $request->validate([
            'fembed_youtube' => 'required',
            'kutipan' => 'required'
        ]);

        //create ke database
        Testimoni::findOrFail($id)->update([
            'fembed_youtube' => $request->fembed_youtube,
            'kutipan' => $request->kutipan
        ]);
        
        return redirect('testimoni_admin')->with('massage', 'Berhasil Mengubah Testimoni');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // dd ($request->gambar_lama);

        Testimoni::destroy($id);

        return redirect('testimoni_admin')->with('massage', 'Berhasil Menghapus Testimoni');
    }
}
